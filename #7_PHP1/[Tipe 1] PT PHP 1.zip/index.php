<?php
# Tidak diperkenankan untuk mengubah array
    $data = [
        [
            "nama" => "Haniif",
            "nim" => "712001",
            "matkul" => ["RPLBO" => "A", "DesEks" => "B", "PDAP" => "D"],
        ],
        [
            "nama" => "Christina",
            "nim" => "712002",
            "matkul" => ["PBL" => "D", "DEA" => "B"],
        ],
        [
            "nama" => "Richard",
            "nim" => "712003",
            "matkul" => ["ProgDesk" => "B"],
        ],
        [
            "nama" => "Kiki",
            "nim" => "712004",
            "matkul" => ["RPLBO" => "A", "PDAP" => "B", "ProgHyb" => "C"],
        ],
    ];
# Tidak diperkenankan untuk mengubah array
    $predikat = [
        "A" => "Sangat Baik",
        "B" => "Baik",
        "C" => "Cukup",
        "D" => "Kurang",
    ];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PT PHP 1</title>
    <style>
        td{
            padding: 5px;
        }
    </style>
</head>
<body>
    <!-- Isi kode Anda di sini -->
</body>
</html>