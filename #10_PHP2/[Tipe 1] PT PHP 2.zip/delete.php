<?php
//kode anda
?>