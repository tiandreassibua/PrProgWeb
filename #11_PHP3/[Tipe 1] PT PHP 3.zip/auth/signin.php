<?php

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BIN | Sign In</title>
    <link rel="stylesheet" href="../styles/signin.css">
</head>
<body>
    <main>
        <form action="signin.php" method="post" id="msform">
            <fieldset>
                <h1>Badan Intelejen Negara</h1>
                <img src="../assets/logo-bin.png" alt="Logo BIN" width="200px" height="200px">
                <div class="email-box">
                    <label for="email">Email</label>
                    <input type="email" id="email" placeholder="name@example.com" name="email" required>
                </div>
                <div class="password-box">
                    <label for="password">Password</label>
                    <input type="password" id="password" placeholder="********" name="password" required>
                </div>
                <div class="btn-center">
                    <button type="submit" class="action-button" name="submit">Sign In</button>
                </div>
            </fieldset>
        </form>
    </main>
</body>
</html>